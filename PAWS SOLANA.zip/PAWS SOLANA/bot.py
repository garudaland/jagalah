import base64
import json
import os
import random
import sys
import time
from urllib.parse import parse_qs, unquote
from datetime import datetime, timedelta
from generate import generate_sol
from paws import Paws
import asyncio


def print_(word):
    now = datetime.now().isoformat(" ").split(".")[0]
    print(f"[{now}] | {word}")


def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')
    
def load_query():
    try:
        with open('paws_query.txt', 'r') as f:
            queries = [line.strip() for line in f.readlines()]
        return queries
    except FileNotFoundError:
        print("File paws_query.txt not found.")
        return [  ]
    except Exception as e:
        print("Failed get Query :", str(e))
        return [  ]

def load_address():
    try:
        with open('address.txt', 'r') as f:
            queries = [line.strip() for line in f.readlines()]
        return queries
    except FileNotFoundError:
        print("File address.txt not found.")
        return [  ]
    except Exception as e:
        print("Failed get Query :", str(e))
        return [  ]

def load_sol_address():
    try:
        with open('sol_address.txt', 'r') as f:
            queries = [line.strip() for line in f.readlines()]
        return queries
    except FileNotFoundError:
        print("File address.txt not found.")
        return [  ]
    except Exception as e:
        print("Failed get Query :", str(e))
        return [  ]

def load_mnemonic():
    with open('mnemonic_12.txt', 'r') as f:
        list_mnemonic_12 = [line.strip() for line in f.readlines()]
    return list_mnemonic_12

def parse_query(query: str):
    parsed_query = parse_qs(query)
    parsed_query = {k: v[0] for k, v in parsed_query.items()}
    user_data = json.loads(unquote(parsed_query['user']))
    parsed_query['user'] = user_data
    return parsed_query

def print_delay(delay):
    print()
    while delay > 0:
        now = datetime.now().isoformat(" ").split(".")[0]
        hours, remainder = divmod(delay, 3600)
        minutes, seconds = divmod(remainder, 60)
        sys.stdout.write(f"\r[{now}] | Waiting Time: {round(hours)} hours, {round(minutes)} minutes, and {round(seconds)} seconds")
        sys.stdout.flush()
        time.sleep(1)
        delay -= 1
    print_("Waiting Done, Starting....\n")

def main():
    start_time = time.time()
    clear_terminal()
    queries = load_query()
    adresses = load_address()
    sum = len(queries)
    paw = Paws()
    total_balance = 0
    for index, query in enumerate(queries):
        users = parse_query(query).get('user')
        id = users.get('id')
        print_(f"[SxG]======= Account {index+1}/{sum} [ {users.get('username')} ] ========[SxG]")
        auth = paw.auth(query)
        if auth is not None:
            data = auth.get('data')
            token = data[0]
            datas = data[1]
            userData =datas.get('userData')
            wallet = userData.get('wallet',None)
            allocationData = datas.get('allocationData')
            gameData = datas.get('gameData')
            balance = gameData.get('balance')
            total_balance += balance
            total = allocationData.get('total',0)
            print_(f"Total Balance : {balance}")
            if wallet is None:
                print_('SOL Wallet Address not found')
                address = adresses[index]
                if address is None:
                    print_('Address not found')
                else:
                    paw.bind_wallet(token, address)
            print_('Get Task')
            # paw.grinch(token=token)
            paw.quest_list(token=token)
            # paw.quest_christmas(token=token)
            
    print_(f"Total {total_balance} Paws From {sum} Account")
            
def connect_ton():
    start_time = time.time()
    clear_terminal()
    queries = load_query()
    adresses = load_address()
    sum = len(queries)
    paw = Paws()
    total_balance = 0
    for index, query in enumerate(queries):
        users = parse_query(query).get('user')
        id = users.get('id')
        print_(f"[SxG]======= Account {index+1}/{sum} [ {users.get('username')} ] ========[SxG]")
        auth = paw.auth(query)
        if auth is not None:
            data = auth.get('data')
            token = data[0]
            datas = data[1]
            userData =datas.get('userData')
            wallet = userData.get('wallet',None)
            allocationData = datas.get('allocationData')
            gameData = datas.get('gameData')
            balance = gameData.get('balance')
            total_balance += balance
            total = allocationData.get('total',0)
            print_(f"Total Balance : {balance}")
            if wallet is None:
                print_('Wallet Address not found')
                address = adresses[index]
                if address is None:
                    print_('Address not found')
                else:
                    paw.bind_wallet(token=token, address=wallet)
            else:
                print_(f"Wallet address : {wallet}")


def disconnect_wallet():
    start_time = time.time()
    clear_terminal()
    queries = load_query()
    adresses = load_address()
    sum = len(queries)
    paw = Paws()
    total_balance = 0
    for index, query in enumerate(queries):
        users = parse_query(query).get('user')
        id = users.get('id')
        print_(f"[SxG]======= Account {index+1}/{sum} [ {users.get('username')} ] ========[SxG]")
        auth = paw.auth(query)
        if auth is not None:
            data = auth.get('data')
            token = data[0]
            datas = data[1]
            userData =datas.get('userData')
            wallet = userData.get('wallet',None)
            allocationData = datas.get('allocationData')
            gameData = datas.get('gameData')
            balance = gameData.get('balance')
            total_balance += balance
            total = allocationData.get('total',0)
            print_(f"Total Balance : {balance}")
            if wallet is None:
                print_('Wallet Address not found')

            else:
                paw.disconnect_sol(token)
                print_(f"Wallet address : {wallet}")

async def connect_sol():
    queries = load_query()
    adresses = load_sol_address()
    list_mnemonic = load_mnemonic()
    sum = len(queries)
    paw = Paws()
    total_balance = 0
    for index, query in enumerate(queries):
        users = parse_query(query).get('user')
        id = users.get('id')
        print_(f"[SxG]======= Account {index+1}/{sum} [ {users.get('username')} ] ========[SxG]")
        auth = paw.auth(query)
        if auth is not None:
            data = auth.get('data')
            token = data[0]
            datas = data[1]
            userData =datas.get('userData')
            sol_wallet = userData.get('solanaWallet',None)
            wallet = userData.get('wallet',None)
            proofTonWallet = userData.get('proofTonWallet', None)
            proofSolanaWallet = userData.get('proofSolanaWallet', None)
            allocationData = datas.get('allocationData')
            gameData = datas.get('gameData')
            balance = gameData.get('balance')
            total_balance += balance
            total = allocationData.get('total',0)
            print_(f"Total Balance : {balance}")
            # if wallet is None:
            #     print_('SOL Wallet Address not found')
            #     address = adresses[index]
            #     if address is None:
            #         print_('Address not found')
            #     else:
            #         paw.connect_sol(token, address)
            sol_address = ""
            ton_address = ""
            if proofSolanaWallet is None:
                payload = paw.payload_solana()
                if payload is not None:
                    mnemonic = None
                    public_key, signature = await generate_sol(mnemonic, payload)
                    sol_address = public_key
                    payload = {"signature":signature,"publicKey":public_key,"token":payload}
                    paw.checkproof_solana(payload, token)
            else:
                print_(f"Wallet address : {proofSolanaWallet}")
            
            if proofTonWallet is None:
                payload = paw.payload_ton(token)
                if payload is not None:
                    mnemonic = None
                    loads = await proof("app.paws.community", payload, mnemonic)
                    ton_address = loads[1]
                    paw.checkproof_ton(loads[0], token)
            else:
                print_(f"Wallet address : {proofTonWallet}")
            
            if wallet is None:
                paw.bind_wallet(token, ton_address)
            else:
                print_(f"Wallet address : {wallet}")
            
            if sol_wallet is None:
                paw.connect_sol(token, sol_address)
            else:
                print_(f"Wallet address : {sol_wallet}")
            
            paw.quest_list(token=token)


async def activity_check():
    list_mnemonic = load_mnemonic()
    sum = len(list_mnemonic)
    paw = Paws()
    total_balance = 0
    for index, mnemonic in enumerate(list_mnemonic, start=1):
        payload = paw.payload_solana()
        if payload is not None:
            public_key, signature = await generate_sol(mnemonic, payload)
            sol_address = public_key
            payload = {"type":"solana","proof":{"signature":signature,"publicKey":public_key,"token":payload}}
            data_auth = await paw.wallet_auth(payload)
            if data_auth is not None:
                token = data_auth.get('token')
                user = data_auth.get('user')
                userData = user.get('userData')
                username = userData.get('username')
                print_(f"[SxG]============= Account {index}/{sum} | {username} =============[SxG]")
                print_(f"Check Eligibility")
                data_elig = await paw.eligibility(token)
                if data_elig is not None:
                    if len(data_elig) > 0:
                        for data in data_elig:
                            criteriaName = data.get('criteriaName')
                            requiredValue = data.get('requiredValue')
                            userValue = data.get('userValue')
                            meetsCriteria = data.get('meetsCriteria')
                            if criteriaName == "activityCheck":
                                if userValue == requiredValue and meetsCriteria == requiredValue:
                                    print_(f"Acitivty Check is Done")
                                else:
                                    await paw.activity_checker(token)


async def start():
    print("""
               PAWS BOT
        1. claim
        2. connect wallet ton
        3. connect wallet sol
        4. disconnect wallet
        5. activity check
""")
    choice = input("Enter your choice : ")
    if choice == '1':
        main()
    elif choice == '2':
        connect_ton()
    elif choice == '3':
        await connect_sol()
    elif choice == '4':
        disconnect_wallet()
    elif choice == '5':
        await activity_check()
    else:
        print("Invalid choice")

if __name__ == "__main__":
    asyncio.run(start())