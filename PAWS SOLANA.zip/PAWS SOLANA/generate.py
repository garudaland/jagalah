from solders.keypair import Keypair # type: ignore
from mnemonic import Mnemonic
import asyncio
import os


async def generate_sol(mnemonic=None, payload=None):
    mnemo = Mnemonic("english")
        #"m/44'/501'/0'/0'"
    # path = f"m/44'/501'/{i}'/0'"
    if mnemonic is None:
        mnemonic = mnemo.generate(strength=128)
        with open('mnemonic_12.txt', 'a') as f:
            f.write(f"{mnemonic}\n")
    seed = mnemo.to_seed(mnemonic)
    path = "m/44'/501'/0'/0'"
    keypair = Keypair.from_seed_and_derivation_path(seed, path)
    public_key = keypair.pubkey()
    s_bytes = payload.encode()
    datas = keypair.sign_message(s_bytes)
    return str(public_key), str(datas)