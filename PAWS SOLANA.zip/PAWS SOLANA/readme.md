# PAWS BOT

## LINK BOT: [Register Here](https://t.me/PAWSOG_bot/PAWS?startapp=1mFY7Q2p)
## TUTORIAL IN CHANNEL : [Join Here](https://t.me/sansxgroup)
## ASK IN GROUPCHAT : [Join Here](https://t.me/sansxgroup_chat)

## Features
- Auto Clear Task
- Auto Connect Wallet